<div id="UM_preview_form" style="display:none">

	<div class="um-admin-modal-head">
		<h3><?php _e('Live Form Preview','ultimatemember'); ?></h3>
	</div>
	
	<div class="um-admin-modal-body">

	</div>
	
	<div class="um-admin-modal-foot">
		<a href="#" class="button-primary" data-action="UM_remove_modal"><?php _e('Continue editing','ultimatemember'); ?></a>
	</div>
	
</div>