<div id="UM_add_divider" style="display:none">

	<form action="" method="post" class="um_add_field">
	
	<div class="um-admin-modal-head">
		<h3><?php _e('Add a New Divider','ultimatemember'); ?></h3>
	</div>
	
	<div class="um-admin-modal-body um-admin-metabox">

	</div>

	<div class="um-admin-modal-foot">
		<input type="submit" value="<?php _e('Add','ultimatemember'); ?>" class="button-primary" />
		<a href="#" data-action="UM_remove_modal" class="button"><?php _e('Cancel','ultimatemember'); ?></a>
	</div>
	
	</form>
	
</div>